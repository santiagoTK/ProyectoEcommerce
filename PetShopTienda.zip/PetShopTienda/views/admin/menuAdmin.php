    <div id="principal">
      <?php if(isset($_SESSION['admin'])): ?>
        <section class="uno1">
          <h2>CLIENTES</h2>
          
          <a href="<?=base_url?>client/manage" class="leer-mas1">Listar Clientes</a><br><br>

        </section>
        <section class="uno1 dos">
          <h2>Categorias</h2> 
        
        
          <a href="<?=base_url?>category/index" class="leer-mas1">Listar Categorias</a><br><br>

        </section>
        <section class="uno1">
          <h2>PRODUCTOS</h2>

        
          <a href="<?=base_url?>product/manage" class="leer-mas1">Listar Productos</a><br><br>

        </section>
		<br class="clearfix">

        <section class="uno1">
          <h2>REGISTRO PEDIDOS</h2>

        
          <a href="<?=base_url?>order/manage" class="leer-mas1">Listar Pedidos</a><br><br>

        </section>
         <section class="uno1 dos">
          <h2>VENTAS</h2>

        
          <a href="<?=base_url?>sale/manage" class="leer-mas1">Listar Ventas</a><br><br>

        </section>
         <?php endif; ?>
    </div>

