   <?php
    
     public function admin(){
        Utils::isAdmin();

        $product = new Product();
        $products = $product->getProducts();
        require_once 'views/admin/menuAdmin.php';
    }




  ?> 