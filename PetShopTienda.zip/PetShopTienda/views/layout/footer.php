</div>  <!-- End content-wrapper   -->
   <!-- Footer  -->
   <footer class="footer">
        <div class="footer-container">
            <div class="footer-column footer-categories">
                <div class="footer-title">
                    <h3>Categorías</h3>
                </div>
                <div class="footer-list">
                    <ul>
                        <li>Alimento para perro</li>
                        <li>Alimento para gato</li>
                        <li>Limpieza</li>
                        <li>Accesorios</li>
                        <li>Juguetes</li>
                    </ul>
                </div>
            </div>
            <div class="footer-column footer-about">
                <div class="footer-title">
                    <h3>Acerca de PetShop</h3>
                </div>
                <div class="footer-list">
                    <ul>
                        <li>¿Quienes somos?</li>
                        <li>Nuestra misión</li>
                        <li>Preguntas frecuentes</li>
                        <li>Política de privacidad</li>
                        <li>Soporte</li>
                    </ul>
                </div>
            </div>
            <div class="footer-column footer-contact">
                <div class="footer-title">
                    <h3>Contacto</h3>
                </div>
                <div class="footer-list">
                    <ul>
                        <li>Email:<br>petshop@mail.com</li>
                        <li>+57 6017319375</li>
                    </ul>
                </div>
            </div>
            <div class="footer-column footer-subscribe">
                <div class="footer-title">
                    <h3>Suscríbete</h3>
                </div>
                <div class="footer-form">
                    <form action="<?=base_url?>subscribe/subscribe" method="POST" class="subscribe-form">
                        <div class="form-group">
                            <label for="mail">Ingresa tu Email</label>
                            <input type="email" name="mail" id="mail">
                        </div>
                        <input type="submit" class="btn btn-footer" value="Suscribirse">                       
                    </form>
                </div>
            </div>
        </div>
    </footer>
</div>   <!-- End page container   -->
</body>
</html>