<?php if(isset($_SESSION['order']) && $_SESSION['order' ]== "completed"): ?>
    <div class="confirmed-container">
        <h1 class="text-align-center">Pedido Confirmado</h1>
        <h4 class="table-align">¡Tu pedido se ha realizado correctamente! Aquí está la información:</h4>
        <table>
            <tr>
                <th>ID de Pedido</th>
                <th>Dirección de entrega</th>
                <th>Fecha</th>
                <th>Hora</th>
                <th>Precio total</th>
            </tr>
            <tr>
                <?php $lastOrder = $lastOrder->fetch_object(); ?>
                <td><?=$lastOrder->id;?></td>
                <td><?=$lastOrder->address;?></td>
                <td><?=$lastOrder->date;?></td>
                <td><?=$lastOrder->time;?></td>
                <td><?=$lastOrder->total_price;?></td>
            </tr>
        </table>
        <div class="table-align">
            <button class="btn">
                <a href="<?=base_url?>order/toDownload">
                    Descargar Confirmación
                </a>
            </button>
        </div>
    </div>
<?php elseif(isset($_SESSION['order']) && $_SESSION['order' ] != "completed"):?>
    <h3 class="table-align">Sorry, your order could not be processed.</h3>
<?php endif; ?>