<?php $lastOrder = $toFetch->fetch_object(); ?>
<style>
    span{
        font-weight: bold;
    }

    .product-group img, .product-group p{
        display: inline;
    }

    h4{
        margin-bottom: 0px;
    }
</style>

<h1 style="text-align: center;">Su pedido</h1>
<hr>
<p><span>ID de pedido:</span> <?=$lastOrder->id?></p>
<p><span>Dirección:</span> <?=$lastOrder->address?>, <?=$lastOrder->city?>, <?=$lastOrder->state?></p>
<p><span>Fecha de pedido:</span> <?=$lastOrder->date?></p>
<p><span>Hora de pedido:</span> <?=$lastOrder->time?></p>


<div style="margin-top: 20px;">
        <?php if(isset($_SESSION['cart'])){
            $cart = $_SESSION['cart'];
        }  
        ?> 
        <h2>Elementos comprados</h2>       
         <?php if(isset($_SESSION['cart'])): 
          foreach($cart as $index => $product): 
            $item = $product['product'];        
            ?>

            
        
            <h4><span>Item <?=$index+1?>:</span>
                <a href="<?=base_url?>product/singleProduct&id=<?=$item->id?>"><?= $item->name; ?></a>
            </h4>
            <ul>
                <li>
                    <span>
                    Precio:
                    </span>
                    <?= $item->price?>
                </li>
                <li>
                    <span>
                    Unidades:
                    </span>
                    <?= $product['unities']?>
                </li>
            </ul>
        
            <?php endforeach;
        endif;
        ?>
    </div>

    <h3><span>Precio total:</span> $<?=$lastOrder->total_price?></h3>

    <br><h2>Infomación de pago</h2>
    <h3>Consignación bancaria:</h3>
    <h4>Banco Hood Robin</h4>
    <h4>Número de cuenta: xxxx xxxx xxxx xxxx</h4>