    <!-- Hero Area  -->
    <section class="container-slider">
      <div class="slider" id="slider">
        <div class="hero-img slider_section">
            <h2>¿Que quiere tu <span class="green">Mascota</span>?</h2>
        </div>
        <div class="slider_section">
             <img src="assets/mesa1.JPG" alt="" class="slider_img">
         </div>
         <div class="slider_section">
             <img src="assets/mesa2.JPG" alt="" class="slider_img">
        </div>
      <div class="slider_btn slider_left" id="btn_left">&#60;</div>
      <div class="slider_btn slider_rigth" id="btn_rigth">&#62;</div>
    </div>
    </section>
   <script src="views/Java/slider.js"></script> 


    <!-- Products Area  -->
    <section class="products">
        <div class="products-title">
            <h2>Productos</h2>
        </div>
        <div class="products-display">
            <?php while ($product = $products->fetch_object()):?>
            <div class="product">
                <div class="product-img" style="background-image: url('<?=base_url?>uploads/images/<?=$product->image?>');">
                    <!-- <img src="write base url here!!! assets/img/product1.png" alt="product image"> -->
                </div>
                <div class="product-title">
                    <h4><?=$product->name?></h4>
                </div>
                <div class="product-title">
                    <p>$<?=$product->price?></p>
                </div>
                <div class="product-description">
                    <p>
                        <?=$product->description?>
                    </p>
                </div>
                <button class="btn btn-see-more"><a href="<?=base_url?>product/singleProduct&id=<?=$product->id?>">Ver más</a> </button>
            </div>
            <?php endwhile; ?>         
        </div>
    </section>