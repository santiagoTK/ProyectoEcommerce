<div class="product-container">
    <h2 style="text-align: center">Listar Ventas</h2>
    <div class="add-product">
        <!--<button class="btn add-product"><a href="<?=base_url?>product/create">Agregar Producto</a> </button>-->

        <!-- feedback display when adding product -->
        <?php if(isset($_SESSION['product']) && $_SESSION['product'] == "completed"): ?>
            <p>Product successfully added!</p>
            <?php elseif(isset($_SESSION['product']) && $_SESSION['product'] !== "completed"): ?>
            <p style="color: red;">Product could not be added!</p>
        <?php endif; ?>
        <?php Utils::deleteSession('product'); ?>

        <!-- feedback display when deleting product -->
        <?php if(isset($_SESSION['deleted']) && $_SESSION['deleted'] == "completed"): ?>
            <p>Successfully deleted!</p>
            <?php elseif(isset($_SESSION['deleted']) && $_SESSION['deleted'] !== "completed"): ?>
            <p style="color: red;">Delete failed!</p>
        <?php endif; ?>
        <?php Utils::deleteSession('deleted'); ?>
    </div>

    <table>
        <tr>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Fecha</th>
            <th>Producto</th>
            <th>Precio total</th>
            <!--<th>Acciones</th>-->
        </tr>
        
        <?php while($sale = $sales->fetch_object()): ?>
        <tr>
            <td><?=$sale->first_name;?></td>
            <td><?=$sale->last_name;?></td>
            <td><?=$sale->date;?></td>
            <td><?=$sale->name;?></td>
            <td><?=$sale->total_price;?></td>
        <!--<td>
                <a href="<?=base_url?>sale/delete&id=<?=$sale->id;?>"><i class="trash-icon fas fa-trash"></i></a>
                <a href="<?=base_url?>sale/edit&id=<?=$sale->id;?>"><i class="edit-icon fas fa-edit"></i></a>
            </td>-->
        </tr>
        <?php endwhile; ?>
    </table>
</div>