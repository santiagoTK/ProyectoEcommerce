<div class="success-container">    
    <h1 class="text-align-center">Wecome to the family!</h1>
    <h3 class="text-align-center">Your subscription was successful!</h3>
    <img class="align-img-center medium-img" src="<?=base_url?>assets/img/success.jpg" alt="">
</div>