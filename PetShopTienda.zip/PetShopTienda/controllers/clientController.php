<?php
require_once 'models/client.php';

class clientController{

    public function manage(){
            Utils::isAdmin();

            $client = new Client();
            $clients = $client->getClients();
            require_once 'views/client/manage.php';
    }
}
?>