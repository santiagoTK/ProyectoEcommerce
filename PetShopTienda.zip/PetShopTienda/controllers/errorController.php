<?php

class errorController{
    public function index(){
        echo "<h1>Page not found!!!</h1>";
    }

}