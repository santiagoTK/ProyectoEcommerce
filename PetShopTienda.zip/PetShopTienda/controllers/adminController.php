<?php

class adminController{

    public function showPanel(){
            Utils::isAdmin();

            require_once 'views/admin/menuAdmin.php';
    }
}
?>