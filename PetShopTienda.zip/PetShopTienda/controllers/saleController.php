<?php
require_once 'models/sale.php';

class saleController{

public function manage(){
        Utils::isAdmin();

        $sale = new Sale();
        $sales = $sale->getSales();
        require_once 'views/sale/manage.php';
    }
}
?>