<?php

class Calculator{
    public function __construct()
    {
        echo "Calculadora";
    }

    public function suma($a,$b)
    {
        return $a+$b;
    }
}