<?php
// The define() function defines a constant
define("base_url", "http://localhost/pyct/PetShopTienda/");
define("default_controller", "productController");
define("default_action", "index");