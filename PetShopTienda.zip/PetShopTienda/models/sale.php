<?php

class Sale{
	
	private $db;

	public function __construct(){
        $this->db = Database::connect();
    }

    public function getSales(){
        $sales = $this->db->query("SELECT first_name, last_name, orders.date, name, total_price FROM users INNER JOIN orders ON users.id = orders.user_id INNER JOIN ordersproducts ON orders.id = ordersproducts.order_id INNER JOIN products ON ordersproducts.product_id = products.id WHERE role = 'user'");
        return $sales;
    }
}
?>