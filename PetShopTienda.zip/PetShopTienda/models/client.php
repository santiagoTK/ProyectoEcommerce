<?php

class Client{
	
	private $db;

	public function __construct(){
        $this->db = Database::connect();
    }

    public function getClients(){
        $clients = $this->db->query("SELECT * FROM users WHERE role = 'user'");
        return $clients;
    }

}
?>